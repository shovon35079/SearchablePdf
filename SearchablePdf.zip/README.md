# Searchable PDF (Android)

স্ক্যান করা PDF → OCR → সার্চ করা যায় এমন PDF। মূল পেজের ছবি/লেখা অপরিবর্তিত থাকে; শুধু অদৃশ্য টেক্সট লেয়ার যোগ হয়।

## APK বানানোর নিয়ম
1. GitHub-এ নতুন রিপোজিটরি খুলুন।
2. রিপোজিটরির রুটে `SearchablePdf.zip` আপলোড করুন।
3. `.github/workflows/build.yml` ফাইলটি আলাদাভাবে একই রিপোজিটরিতে আপলোড করুন (workflow ফাইল zip-এর ভেতরে থাকলে চলে না)।
4. Actions ট্যাবে বিল্ড শেষ হলে Artifacts থেকে `app-debug.apk` নামান।

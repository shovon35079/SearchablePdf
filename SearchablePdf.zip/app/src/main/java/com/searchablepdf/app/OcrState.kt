package com.searchablepdf.app

import android.net.Uri
import androidx.lifecycle.MutableLiveData

enum class Status { IDLE, RUNNING, DONE, ERROR, CANCELLED }

data class OcrUiState(
    val status: Status = Status.IDLE,
    val page: Int = 0,
    val total: Int = 0,
    /** চলাকালীন: ইউজারকে দেখানোর টেক্সট। শেষে: ফলাফল বা ত্রুটির বার্তা। */
    val message: String = "",
    val outputPath: String? = null,
    val outputName: String? = null
)

/** Service আর Activity-র মধ্যে অবস্থা শেয়ার করার জন্য (একই প্রসেস)। */
object OcrState {
    val state = MutableLiveData(OcrUiState())

    @Volatile
    var selectedUri: Uri? = null

    @Volatile
    var selectedName: String? = null

    @Volatile
    var cancelRequested: Boolean = false

    fun post(s: OcrUiState) {
        state.postValue(s)
    }
}

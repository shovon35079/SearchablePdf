package com.searchablepdf.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.state.RenderingMode
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.util.Matrix
import java.io.File
import java.io.IOException
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

class OcrCancelled : Exception()

data class OcrResult(
    val total: Int,
    val ocrPages: Int,
    val skippedPages: Int,
    val failedPages: Int,
    val words: Int
)

/**
 * পদ্ধতি:
 *  1. মূল PDF PDFBox দিয়ে খোলা হয় — পেজের ছবি/লেখা কখনো আবার আঁকা বা কমপ্রেস করা হয় না।
 *  2. OCR-এর জন্য শুধু একটি অস্থায়ী ছবি (PdfRenderer) বানানো হয়, পেজ প্রতি একবার করে।
 *  3. OCR-এর ফল (লাইন + অবস্থান) মূল পেজের কনটেন্টের ওপর "অদৃশ্য টেক্সট" (render mode 3) হিসেবে যোগ হয়।
 *  ফলে পেজ দেখতে হুবহু আগের মতো থাকে, কিন্তু সার্চ/সিলেক্ট/কপি করা যায়।
 */
class PdfOcrEngine(private val context: Context) {

    fun run(
        input: File,
        output: File,
        skipPagesWithText: Boolean,
        isCancelled: () -> Boolean,
        onProgress: (done: Int, total: Int) -> Unit
    ): OcrResult {
        PDFBoxResourceLoader.init(context.applicationContext)

        val recognizer: TextRecognizer =
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        var doc: PDDocument? = null
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null

        try {
            doc = PDDocument.load(input, MemoryUsageSetting.setupMixed(32L * 1024 * 1024))
            doc.setAllSecurityToBeRemoved(true)

            pfd = ParcelFileDescriptor.open(input, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)

            val total = minOf(renderer.pageCount, doc.numberOfPages)
            if (total <= 0) throw IOException("PDF-এ কোনো পেজ নেই")

            val pages = doc.pages
            val font: PDFont = PDType1Font.HELVETICA

            var maxLong = if (Runtime.getRuntime().maxMemory() > 300L * 1024 * 1024) 3200 else 2400
            var ocrPages = 0
            var skipped = 0
            var failed = 0
            var words = 0

            onProgress(0, total)

            for (i in 0 until total) {
                if (isCancelled()) throw OcrCancelled()

                val page = pages.get(i)

                if (skipPagesWithText && pageHasText(doc, i)) {
                    skipped++
                } else {
                    var attempt = 0
                    var done = false
                    while (!done) {
                        try {
                            words += ocrOnePage(renderer, i, recognizer, doc, page, font, maxLong)
                            ocrPages++
                            done = true
                        } catch (oom: OutOfMemoryError) {
                            System.gc()
                            attempt++
                            maxLong = (maxLong * 0.7).toInt().coerceAtLeast(1200)
                            if (attempt >= 2) {
                                failed++
                                done = true
                            }
                        } catch (c: OcrCancelled) {
                            throw c
                        } catch (e: Exception) {
                            failed++
                            done = true
                        }
                    }
                }

                onProgress(i + 1, total)
            }

            if (isCancelled()) throw OcrCancelled()
            doc.save(output)

            return OcrResult(total, ocrPages, skipped, failed, words)
        } finally {
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
            try { doc?.close() } catch (_: Exception) {}
            try { recognizer.close() } catch (_: Exception) {}
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun pageHasText(doc: PDDocument, index: Int): Boolean {
        return try {
            val stripper = PDFTextStripper()
            stripper.startPage = index + 1
            stripper.endPage = index + 1
            stripper.getText(doc).trim().length >= 20
        } catch (e: Exception) {
            false
        }
    }

    private fun ocrOnePage(
        renderer: PdfRenderer,
        index: Int,
        recognizer: TextRecognizer,
        doc: PDDocument,
        page: PDPage,
        font: PDFont,
        maxLong: Int
    ): Int {
        val bmp = renderPage(renderer, index, maxLong)
        try {
            val result = Tasks.await(recognizer.process(InputImage.fromBitmap(bmp, 0)))
            return addInvisibleText(doc, page, result, bmp.width, bmp.height, font)
        } finally {
            bmp.recycle()
        }
    }

    /** OCR-এর জন্য পেজের একটি সাদা-ব্যাকগ্রাউন্ড ছবি বানায় (লম্বা দিক ≈ maxLong পিক্সেল)। */
    private fun renderPage(renderer: PdfRenderer, index: Int, maxLong: Int): Bitmap {
        val page = renderer.openPage(index)
        try {
            val w = max(1, page.width)
            val h = max(1, page.height)
            val scale = maxLong.toFloat() / max(w, h).toFloat()
            val bw = max(32, (w * scale).roundToInt())
            val bh = max(32, (h * scale).roundToInt())
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            page.close()
        }
    }

    /**
     * OCR-এর প্রতিটি লাইন মূল পেজে অদৃশ্য টেক্সট হিসেবে বসায়।
     * পেজ ঘোরানো (/Rotate) ও CropBox হিসাবে ধরা হয়েছে।
     * @return পাওয়া শব্দের সংখ্যা
     */
    private fun addInvisibleText(
        doc: PDDocument,
        page: PDPage,
        text: Text,
        bw: Int,
        bh: Int,
        font: PDFont
    ): Int {
        if (text.textBlocks.isEmpty()) return 0

        val crop = page.cropBox
        val cw = crop.width
        val ch = crop.height
        val rot = ((page.rotation % 360) + 360) % 360
        val sideways = rot == 90 || rot == 270
        val dispW = if (sideways) ch else cw
        val dispH = if (sideways) cw else ch
        val sx = dispW / bw
        val sy = dispH / bh

        // ডিসপ্লে স্পেস (বাম-উপর থেকে, y নিচের দিকে) → PDF ইউজার স্পেস
        fun mapPointX(dx: Float, dy: Float): Float = when (rot) {
            90 -> dy
            180 -> cw - dx
            270 -> cw - dy
            else -> dx
        }

        fun mapPointY(dx: Float, dy: Float): Float = when (rot) {
            90 -> dx
            180 -> dy
            270 -> ch - dx
            else -> ch - dy
        }

        fun mapVecX(vx: Float, vy: Float): Float = when (rot) {
            90 -> vy
            180 -> -vx
            270 -> -vy
            else -> vx
        }

        fun mapVecY(vx: Float, vy: Float): Float = when (rot) {
            90 -> vx
            180 -> vy
            270 -> -vx
            else -> -vy
        }

        var words = 0
        var cs: PDPageContentStream? = null

        try {
            for (block in text.textBlocks) {
                for (line in block.lines) {
                    val corners = line.cornerPoints ?: continue
                    if (corners.size < 4) continue

                    var clean = sanitize(line.text, asciiOnly = false)
                    if (clean.isEmpty()) continue

                    val tl = corners[0]
                    val tr = corners[1]
                    val bl = corners[3]

                    val dxp = (tr.x - tl.x).toFloat()
                    val dyp = (tr.y - tl.y).toFloat()
                    val widthPx = hypot(dxp, dyp)
                    if (widthPx < 2f) continue

                    val dirX = dxp / widthPx
                    val dirY = dyp / widthPx
                    // বিটম্যাপে (y নিচমুখী) "ওপর" দিক = লেখার দিকের ৯০° বামে
                    val upX = dirY
                    val upY = -dirX

                    val heightPx = hypot((bl.x - tl.x).toFloat(), (bl.y - tl.y).toFloat())
                    if (heightPx < 2f) continue

                    // বেসলাইন: লাইনের নিচ থেকে একটু ওপরে (descender বাদ দিয়ে)
                    val baseX = bl.x + upX * 0.2f * heightPx
                    val baseY = bl.y + upY * 0.2f * heightPx

                    val fontSize = (heightPx * sy * 0.85f).coerceIn(1f, 500f)

                    var naturalWidth: Float
                    try {
                        naturalWidth = font.getStringWidth(clean) / 1000f * fontSize
                    } catch (e: Exception) {
                        clean = sanitize(clean, asciiOnly = true)
                        if (clean.isEmpty()) continue
                        naturalWidth = font.getStringWidth(clean) / 1000f * fontSize
                    }
                    if (naturalWidth <= 0f) continue

                    val targetWidth = widthPx * sx
                    val scaleX = (targetWidth / naturalWidth).coerceIn(0.05f, 20f)

                    val dispX = baseX * sx
                    val dispY = baseY * sy

                    val m = Matrix(
                        mapVecX(dirX, dirY) * scaleX,
                        mapVecY(dirX, dirY) * scaleX,
                        mapVecX(upX, upY),
                        mapVecY(upX, upY),
                        crop.lowerLeftX + mapPointX(dispX, dispY),
                        crop.lowerLeftY + mapPointY(dispX, dispY)
                    )

                    if (cs == null) {
                        cs = PDPageContentStream(
                            doc, page, PDPageContentStream.AppendMode.APPEND, true, true
                        )
                        cs.beginText()
                        cs.setRenderingMode(RenderingMode.fromInt(3)) // মোড ৩ = অদৃশ্য টেক্সট
                    }

                    cs.setFont(font, fontSize)
                    cs.setTextMatrix(m)
                    cs.showText(clean)

                    words += clean.split(' ').count { it.isNotEmpty() }
                }
            }
        } finally {
            if (cs != null) {
                try { cs.endText() } catch (_: Exception) {}
                cs.close()
            }
        }
        return words
    }

    /** Helvetica (WinAnsi) যা এনকোড করতে পারে শুধু সেই অক্ষর রাখে; কিছু বিশেষ চিহ্ন সাধারণ চিহ্নে বদলায়। */
    private fun sanitize(s: String, asciiOnly: Boolean): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val c = ch.code
            when {
                c in 0x20..0x7E -> sb.append(ch)
                ch == '‘' || ch == '’' -> sb.append('\'')
                ch == '“' || ch == '”' -> sb.append('"')
                ch == '–' || ch == '—' -> sb.append('-')
                ch == '…' -> sb.append("...")
                ch == '\t' || ch == ' ' -> sb.append(' ')
                !asciiOnly && c in 0xA1..0xFF && c != 0xAD -> sb.append(ch)
                else -> { /* বাদ */ }
            }
        }
        return sb.toString().trim()
    }
}

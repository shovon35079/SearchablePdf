package com.searchablepdf.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.text.format.Formatter
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.content.IntentCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import android.os.Bundle
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var btnPick: MaterialButton
    private lateinit var btnStart: MaterialButton
    private lateinit var btnCancel: MaterialButton
    private lateinit var btnSave: MaterialButton
    private lateinit var btnShare: MaterialButton
    private lateinit var btnOpen: MaterialButton
    private lateinit var switchSkip: MaterialSwitch
    private lateinit var btnWord: MaterialButton
    private lateinit var switchHigh: MaterialSwitch
    private lateinit var switchWithText: MaterialSwitch
    private lateinit var switchEditable: MaterialSwitch
    private var pendingMode: String = OcrService.MODE_PDF
    private lateinit var tvFile: TextView
    private lateinit var tvProgress: TextView
    private lateinit var tvMessage: TextView
    private lateinit var progress: ProgressBar
    private lateinit var layoutProgress: View
    private lateinit var layoutDone: View

    private val ioExecutor = Executors.newSingleThreadExecutor()

    private val pickPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) selectFile(uri)
    }

    private val savePdf =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
            if (uri != null) copyResultTo(uri)
        }

    private val saveDocx =
        registerForActivityResult(ActivityResultContracts.CreateDocument(OcrService.MIME_DOCX)) { uri ->
            if (uri != null) copyResultTo(uri)
        }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // অনুমতি দিক বা না দিক, কাজ শুরু হবে (শুধু নোটিফিকেশন দেখা যাবে না)
            startJob(pendingMode)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPick = findViewById(R.id.btnPick)
        btnStart = findViewById(R.id.btnStart)
        btnCancel = findViewById(R.id.btnCancel)
        btnSave = findViewById(R.id.btnSave)
        btnShare = findViewById(R.id.btnShare)
        btnOpen = findViewById(R.id.btnOpen)
        switchSkip = findViewById(R.id.switchSkip)
        tvFile = findViewById(R.id.tvFile)
        tvProgress = findViewById(R.id.tvProgress)
        tvMessage = findViewById(R.id.tvMessage)
        progress = findViewById(R.id.progress)
        layoutProgress = findViewById(R.id.layoutProgress)
        layoutDone = findViewById(R.id.layoutDone)

        btnPick.setOnClickListener { pickPdf.launch(arrayOf("application/pdf")) }
        btnWord = findViewById(R.id.btnWord)
        switchHigh = findViewById(R.id.switchHigh)
        switchWithText = findViewById(R.id.switchWithText)
        switchEditable = findViewById(R.id.switchEditable)
        switchEditable.setOnCheckedChangeListener { _, checked ->
            // Edit মোডে OCR টেক্সট এমনিতেই দৃশ্যমান হয়ে বসে, তাই অদৃশ্য-টেক্সট সুইচ লাগে না
            switchWithText.isEnabled = !checked && OcrState.state.value?.status != Status.RUNNING
        }

        btnStart.setOnClickListener { onStartClicked(OcrService.MODE_PDF) }
        btnWord.setOnClickListener { onStartClicked(OcrService.MODE_DOCX) }
        btnCancel.setOnClickListener {
            OcrState.cancelRequested = true
            startService(Intent(this, OcrService::class.java).setAction(OcrService.ACTION_CANCEL))
        }
        btnSave.setOnClickListener {
            val st = OcrState.state.value
            if (st?.mime == OcrService.MIME_DOCX) {
                saveDocx.launch(st.outputName ?: "document.docx")
            } else {
                savePdf.launch(st?.outputName ?: "searchable.pdf")
            }
        }
        btnShare.setOnClickListener { shareResult() }
        btnOpen.setOnClickListener { openResult() }

        OcrState.state.observe(this) { render(it) }

        refreshFileLabel()
        handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    // ------------------------------------------------------------ ফাইল বাছাই

    private fun handleIncoming(i: Intent?) {
        if (i == null) return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)
            else -> null
        }
        if (uri != null && OcrState.state.value?.status != Status.RUNNING) {
            selectFile(uri)
        }
    }

    private fun selectFile(uri: Uri) {
        OcrState.selectedUri = uri
        OcrState.selectedName = queryName(uri) ?: "document.pdf"
        // আগের ফলাফল মুছে নতুন ফাইলের জন্য প্রস্তুত
        if (OcrState.state.value?.status != Status.RUNNING) {
            OcrState.state.value = OcrUiState()
        }
        refreshFileLabel()
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) c.getString(idx) else null
        }
    } catch (e: Exception) {
        null
    }

    private fun querySize(uri: Uri): Long = try {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.SIZE)
            if (c.moveToFirst() && idx >= 0 && !c.isNull(idx)) c.getLong(idx) else -1L
        } ?: -1L
    } catch (e: Exception) {
        -1L
    }

    private fun refreshFileLabel() {
        val uri = OcrState.selectedUri
        if (uri == null) {
            tvFile.text = getString(R.string.no_file)
        } else {
            val size = querySize(uri)
            val sizeText = if (size >= 0) Formatter.formatFileSize(this, size) else ""
            tvFile.text = getString(R.string.file_info, OcrState.selectedName ?: "", sizeText).trim()
        }
        updateButtons(OcrState.state.value ?: OcrUiState())
    }

    // ----------------------------------------------------------- কাজ শুরু

    private fun onStartClicked(mode: String) {
        if (OcrState.selectedUri == null) return
        pendingMode = mode
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startJob(mode)
        }
    }

    private fun startJob(mode: String) {
        val uri = OcrState.selectedUri ?: return
        val i = Intent(this, OcrService::class.java).apply {
            action = OcrService.ACTION_START
            data = uri
            putExtra(OcrService.EXTRA_NAME, OcrState.selectedName ?: "document.pdf")
            putExtra(OcrService.EXTRA_SKIP_TEXT, switchSkip.isChecked)
            putExtra(OcrService.EXTRA_MODE, mode)
            putExtra(OcrService.EXTRA_HIGH, switchHigh.isChecked)
            putExtra(OcrService.EXTRA_WITH_TEXT, switchWithText.isChecked)
            putExtra(OcrService.EXTRA_EDITABLE, switchEditable.isChecked)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        OcrState.cancelRequested = false
        OcrState.state.value = OcrUiState(Status.RUNNING, 0, 0, getString(R.string.status_copying))
        ContextCompat.startForegroundService(this, i)
    }

    // ------------------------------------------------------------------ UI

    private fun render(s: OcrUiState) {
        when (s.status) {
            Status.IDLE -> {
                layoutProgress.visibility = View.GONE
                layoutDone.visibility = View.GONE
                tvMessage.visibility = View.GONE
            }

            Status.RUNNING -> {
                layoutProgress.visibility = View.VISIBLE
                layoutDone.visibility = View.GONE
                tvMessage.visibility = View.GONE
                if (s.total > 0) {
                    progress.isIndeterminate = false
                    progress.max = s.total
                    progress.progress = s.page
                } else {
                    progress.isIndeterminate = true
                }
                tvProgress.text = s.message
            }

            Status.DONE -> {
                layoutProgress.visibility = View.GONE
                layoutDone.visibility = View.VISIBLE
                tvMessage.visibility = View.VISIBLE
                tvMessage.text = getString(R.string.done_title) + "\n\n" + s.message
            }

            Status.ERROR, Status.CANCELLED -> {
                layoutProgress.visibility = View.GONE
                layoutDone.visibility = View.GONE
                tvMessage.visibility = View.VISIBLE
                tvMessage.text = s.message
            }
        }
        updateButtons(s)
    }

    private fun updateButtons(s: OcrUiState) {
        val running = s.status == Status.RUNNING
        btnPick.isEnabled = !running
        switchSkip.isEnabled = !running
        switchHigh.isEnabled = !running
        switchWithText.isEnabled = !running && !switchEditable.isChecked
        switchEditable.isEnabled = !running
        val ready = !running && OcrState.selectedUri != null
        btnStart.isEnabled = ready
        btnWord.isEnabled = ready
    }

    // ------------------------------------------------------- ফলাফল নিয়ে কাজ

    private fun resultFile(): File? {
        val path = OcrState.state.value?.outputPath ?: return null
        val f = File(path)
        return if (f.exists()) f else null
    }

    private fun copyResultTo(dest: Uri) {
        val src = resultFile() ?: return
        ioExecutor.execute {
            val ok = try {
                contentResolver.openOutputStream(dest, "wt")?.use { out ->
                    src.inputStream().use { it.copyTo(out, 256 * 1024) }
                } != null
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                Toast.makeText(
                    this,
                    if (ok) R.string.saved_ok else R.string.saved_fail,
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun resultUri(f: File): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", f)

    private fun shareResult() {
        val f = resultFile() ?: return
        val i = Intent(Intent.ACTION_SEND).apply {
            type = OcrState.state.value?.mime ?: "application/pdf"
            putExtra(Intent.EXTRA_STREAM, resultUri(f))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(i, getString(R.string.share_pdf)))
    }

    private fun openResult() {
        val f = resultFile() ?: return
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(resultUri(f), OcrState.state.value?.mime ?: "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_viewer, Toast.LENGTH_LONG).show()
        }
    }
}

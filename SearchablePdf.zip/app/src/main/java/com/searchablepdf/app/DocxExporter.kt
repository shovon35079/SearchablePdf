package com.searchablepdf.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.BufferedOutputStream
import java.io.BufferedWriter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStreamWriter
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * PDF → Word (.docx), হুবহু।
 *
 *  - প্রতিটি PDF পেজ = Word-এর একটি পেজ (একই মাপ, মার্জিন শূন্য)।
 *  - পেজের পুরো ছবি (লেখা + ছবি সহ) পেজ জুড়ে ব্যাকগ্রাউন্ডে বসে, তাই দেখতে PDF-এর সাথে হুবহু এক।
 *  - ঐচ্ছিক: OCR করা প্রতিটি লাইন ছবির ঠিক ওপরে "স্বচ্ছ টেক্সট" হিসেবে বসে, ফলে Word-এ
 *    Ctrl+F দিয়ে সার্চ, সিলেক্ট ও কপি করা যায় — অথচ চোখে কিছু বদলায় না।
 *  - ফাইল সরাসরি ZIP-এ স্ট্রিম করে লেখা হয়; একবারে একটি পেজই মেমোরিতে থাকে, তাই বড় PDF-ও চলে।
 */
class DocxExporter(private val context: Context) {

    private class Rendered(val bmp: Bitmap, val wPt: Float, val hPt: Float)

    private class LineInfo(val text: String, val box: Rect) {
        var bg: Int = Color.WHITE
        var fg: Int = Color.BLACK
        fun fgHex(): String = String.format("%02X%02X%02X", Color.red(fg), Color.green(fg), Color.blue(fg))
    }

    // ------------------------------------------------- Edit মোডের সাহায্যকারী

    private fun median(v: IntArray): Int {
        v.sort()
        return v[v.size / 2]
    }

    /** লাইনের চারপাশ থেকে ব্যাকগ্রাউন্ডের রং, আর ভেতর থেকে লেখার রং অনুমান করে। */
    private fun analyzeLine(bmp: Bitmap, li: LineInfo) {
        val b = li.box
        val maxX = bmp.width - 1
        val maxY = bmp.height - 1
        val pad = max(3, (b.height() * 0.15f).toInt())
        val n = 12
        val rs = ArrayList<Int>()
        val gs = ArrayList<Int>()
        val bs = ArrayList<Int>()
        fun sample(x: Int, y: Int) {
            val p = bmp.getPixel(x.coerceIn(0, maxX), y.coerceIn(0, maxY))
            rs.add(Color.red(p)); gs.add(Color.green(p)); bs.add(Color.blue(p))
        }
        for (k in 0..n) {
            val x = b.left + (b.width() * k) / n
            val y = b.top + (b.height() * k) / n
            sample(x, b.top - pad)
            sample(x, b.bottom + pad)
            sample(b.left - pad, y)
            sample(b.right + pad, y)
        }
        li.bg = Color.rgb(
            median(rs.toIntArray()), median(gs.toIntArray()), median(bs.toIntArray())
        )

        // লেখার রং: বক্সের ভেতরের যে পিক্সেলগুলো ব্যাকগ্রাউন্ড থেকে সবচেয়ে আলাদা, তাদের গড়
        val gx = 24
        val gy = 6
        val dist = ArrayList<Pair<Int, Int>>()
        val br = Color.red(li.bg)
        val bgc = Color.green(li.bg)
        val bb = Color.blue(li.bg)
        for (yy in 0 until gy) {
            for (xx in 0 until gx) {
                val x = (b.left + (b.width() * (xx + 0.5f)) / gx).toInt().coerceIn(0, maxX)
                val y = (b.top + (b.height() * (yy + 0.5f)) / gy).toInt().coerceIn(0, maxY)
                val p = bmp.getPixel(x, y)
                val dr = Color.red(p) - br
                val dg = Color.green(p) - bgc
                val db = Color.blue(p) - bb
                dist.add(Pair(dr * dr + dg * dg + db * db, p))
            }
        }
        dist.sortByDescending { it.first }
        val top = dist.take(max(3, dist.size / 8))
        if (top.isEmpty() || top[0].first < 40 * 40) {
            li.fg = Color.BLACK
        } else {
            li.fg = Color.rgb(
                top.sumOf { Color.red(it.second) } / top.size,
                top.sumOf { Color.green(it.second) } / top.size,
                top.sumOf { Color.blue(it.second) } / top.size
            )
        }
    }

    private fun eraseLines(bmp: Bitmap, lines: List<LineInfo>) {
        val canvas = Canvas(bmp)
        val p = Paint().apply { style = Paint.Style.FILL; isAntiAlias = false }
        for (li in lines) {
            val infl = max(2, (li.box.height() * 0.12f).toInt())
            p.color = li.bg
            canvas.drawRect(
                (li.box.left - infl).toFloat(),
                (li.box.top - infl).toFloat(),
                (li.box.right + infl).toFloat(),
                (li.box.bottom + infl).toFloat(),
                p
            )
        }
    }

    fun run(
        input: File,
        output: File,
        withText: Boolean,
        highQuality: Boolean,
        editable: Boolean,
        isCancelled: () -> Boolean,
        onProgress: (done: Int, total: Int) -> Unit
    ): OcrResult {
        val bodyFile = File(output.parentFile, "body.xml")
        val recognizer: TextRecognizer? =
            if (withText || editable) TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) else null
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        var zip: ZipOutputStream? = null
        var body: BufferedWriter? = null

        try {
            pfd = ParcelFileDescriptor.open(input, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            val total = renderer.pageCount
            if (total <= 0) throw IOException("PDF-এ কোনো পেজ নেই")

            zip = ZipOutputStream(BufferedOutputStream(FileOutputStream(output), 256 * 1024))
            body = BufferedWriter(OutputStreamWriter(FileOutputStream(bodyFile), Charsets.UTF_8), 128 * 1024)

            // স্থির অংশ আগে লিখে ফেলা
            putText(zip, "[Content_Types].xml", CONTENT_TYPES)
            putText(zip, "_rels/.rels", ROOT_RELS)

            val bigHeap = Runtime.getRuntime().maxMemory() > 300L * 1024 * 1024
            var maxLong = if (highQuality) (if (bigHeap) 3400 else 2800) else 2400
            val jpegQuality = if (highQuality) 90 else 82

            val paint = Paint().apply { typeface = Typeface.SANS_SERIF }

            var ocrPages = 0
            var failed = 0
            var words = 0
            var lastW = 11906
            var lastH = 16838

            onProgress(0, total)

            for (i in 0 until total) {
                if (isCancelled()) throw OcrCancelled()

                // ---- পেজ রেন্ডার (মেমোরি কম পড়লে মান কমিয়ে আবার চেষ্টা)
                var r: Rendered? = null
                var attempt = 0
                while (r == null) {
                    try {
                        r = render(renderer, i, maxLong)
                    } catch (oom: OutOfMemoryError) {
                        System.gc()
                        attempt++
                        if (attempt >= 3) throw oom
                        maxLong = (maxLong * 0.75).toInt().coerceAtLeast(1200)
                    }
                }

                val bmp = r.bmp
                try {
                    // ---- পেজের মাপ (twips = ১/২০ পয়েন্ট); Word-এর সর্বোচ্চ ~২২ ইঞ্চি
                    var wTw = r.wPt * 20f
                    var hTw = r.hPt * 20f
                    val k = min(1f, 31000f / max(wTw, hTw))
                    wTw *= k
                    hTw *= k
                    val pageW = max(400, wTw.roundToInt())
                    val pageH = max(400, hTw.roundToInt())
                    lastW = pageW
                    lastH = pageH

                    // ---- OCR (ছবি বদলানোর আগে, মূল ছবির ওপর)
                    val lines = ArrayList<LineInfo>()
                    if (recognizer != null) {
                        try {
                            val res = Tasks.await(recognizer.process(InputImage.fromBitmap(bmp, 0)))
                            for (block in res.textBlocks) {
                                for (line in block.lines) {
                                    val box = line.boundingBox ?: continue
                                    if (line.text.isBlank()) continue
                                    lines.add(LineInfo(line.text, box))
                                }
                            }
                            ocrPages++
                        } catch (c: OutOfMemoryError) {
                            throw c
                        } catch (e: Exception) {
                            failed++
                            lines.clear()
                        }
                    }

                    // ---- Edit মোড: ছবি থেকে লেখা মুছে ব্যাকগ্রাউন্ডের রং দিয়ে ঢেকে দেওয়া
                    //      (ছবি/ছবির বাকি অংশ যেমন আছে তেমনই থাকে)
                    if (editable && lines.isNotEmpty()) {
                        for (li in lines) analyzeLine(bmp, li)
                        eraseLines(bmp, lines)
                    }

                    // ---- ছবি সরাসরি ZIP-এ
                    zip.setLevel(Deflater.NO_COMPRESSION)
                    zip.putNextEntry(ZipEntry("word/media/p${i + 1}.jpg"))
                    bmp.compress(Bitmap.CompressFormat.JPEG, jpegQuality, zip)
                    zip.closeEntry()

                    // ---- টেক্সট ফ্রেম (Edit মোডে দৃশ্যমান ও এডিটযোগ্য; নইলে স্বচ্ছ)
                    val sb = StringBuilder()
                    val tx = pageW.toFloat() / bmp.width
                    val ty = pageH.toFloat() / bmp.height
                    for (li in lines) {
                        words += appendLineFrame(
                            sb, li.text, li.box, tx, ty, paint, pageW, pageH,
                            if (editable) li.fgHex() else null
                        )
                    }

                    // ---- পেজের XML
                    body.write(sb.toString())
                    body.write(
                        carrierParagraph(
                            index = i + 1,
                            pageW = pageW,
                            pageH = pageH,
                            withSectionBreak = i < total - 1
                        )
                    )
                } finally {
                    bmp.recycle()
                }

                onProgress(i + 1, total)
            }

            if (isCancelled()) throw OcrCancelled()

            body.flush()
            body.close()
            body = null

            // ---- document.xml = শুরু + পেজগুলো + শেষ সেকশন
            zip.setLevel(Deflater.DEFAULT_COMPRESSION)
            zip.putNextEntry(ZipEntry("word/document.xml"))
            zip.write(DOC_HEAD.toByteArray(Charsets.UTF_8))
            FileInputStream(bodyFile).use { ins ->
                val buf = ByteArray(256 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    zip.write(buf, 0, n)
                }
            }
            zip.write(
                ("<w:sectPr><w:pgSz w:w=\"$lastW\" w:h=\"$lastH\"/>$PG_MAR</w:sectPr></w:body></w:document>")
                    .toByteArray(Charsets.UTF_8)
            )
            zip.closeEntry()

            val rels = StringBuilder()
            rels.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
            rels.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
            for (n in 1..total) {
                rels.append("<Relationship Id=\"rIdP$n\" ")
                rels.append("Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" ")
                rels.append("Target=\"media/p$n.jpg\"/>")
            }
            rels.append("</Relationships>")
            putText(zip, "word/_rels/document.xml.rels", rels.toString())

            zip.finish()
            zip.close()
            zip = null

            return OcrResult(total, ocrPages, 0, failed, words)
        } finally {
            try { body?.close() } catch (_: Exception) {}
            try { zip?.close() } catch (_: Exception) {}
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
            try { recognizer?.close() } catch (_: Exception) {}
            bodyFile.delete()
        }
    }

    // ------------------------------------------------------------------ রেন্ডার

    private fun render(renderer: PdfRenderer, index: Int, maxLong: Int): Rendered {
        val page = renderer.openPage(index)
        try {
            val w = max(1, page.width)
            val h = max(1, page.height)
            val scale = maxLong.toFloat() / max(w, h).toFloat()
            val bw = max(32, (w * scale).roundToInt())
            val bh = max(32, (h * scale).roundToInt())
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return Rendered(bmp, w.toFloat(), h.toFloat())
        } finally {
            page.close()
        }
    }

    // ---------------------------------------------------------------------- XML

    /** একটি OCR লাইনকে পেজের নির্দিষ্ট জায়গায় স্বচ্ছ টেক্সট ফ্রেম হিসেবে যোগ করে; শব্দসংখ্যা ফেরত দেয়। */
    private fun appendLineFrame(
        sb: StringBuilder,
        raw: String,
        box: Rect?,
        tx: Float,
        ty: Float,
        paint: Paint,
        pageW: Int,
        pageH: Int,
        colorHex: String?
    ): Int {
        if (box == null) return 0
        val text = xmlEscape(raw)
        if (text.isBlank()) return 0

        val x = (box.left * tx).roundToInt().coerceIn(0, pageW - 1)
        val y = (box.top * ty).roundToInt().coerceIn(0, pageH - 1)
        val targetW = (box.width() * tx).roundToInt()
        val h = (box.height() * ty).roundToInt()
        if (targetW < 20 || h < 20) return 0

        // ফন্ট সাইজ (half-points): লাইনের উচ্চতার ≈ ৮০%
        val halfPts = (h * 0.08f).roundToInt().coerceIn(2, 3000)
        paint.textSize = halfPts / 2f
        val natural = paint.measureText(raw.replace('\n', ' ')) * 20f // twips
        if (natural <= 0f) return 0
        val scale = (targetW / natural * 100f).roundToInt().coerceIn(1, 600)

        val frameW = (targetW * 1.05f).roundToInt() + 40

        sb.append("<w:p><w:pPr>")
        sb.append("<w:framePr w:w=\"").append(frameW).append("\" w:h=\"").append(h)
        sb.append(if (colorHex != null) "\" w:hRule=\"atLeast\"" else "\" w:hRule=\"exact\"")
        sb.append(" w:wrap=\"around\" w:vAnchor=\"page\" w:hAnchor=\"page\" w:x=\"")
        sb.append(x).append("\" w:y=\"").append(y).append("\"/>")
        sb.append("<w:spacing w:before=\"0\" w:after=\"0\" w:line=\"").append(h)
        sb.append("\" w:lineRule=\"exact\"/></w:pPr>")
        sb.append("<w:r><w:rPr><w:rFonts w:ascii=\"Arial\" w:hAnsi=\"Arial\" w:cs=\"Arial\"/>")
        if (colorHex != null) sb.append("<w:color w:val=\"").append(colorHex).append("\"/>")
        sb.append("<w:w w:val=\"").append(scale).append("\"/>")
        sb.append("<w:sz w:val=\"").append(halfPts).append("\"/>")
        sb.append("<w:szCs w:val=\"").append(halfPts).append("\"/>")
        if (colorHex == null) sb.append("<w14:textFill><w14:noFill/></w14:textFill>")
        sb.append("</w:rPr>")
        sb.append("<w:t xml:space=\"preserve\">").append(text).append("</w:t></w:r></w:p>")

        return text.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
    }

    /** পেজের ছবি (পেছনে, পেজ জুড়ে) বহনকারী ছোট অনুচ্ছেদ; দরকারে সেকশন-ব্রেকও এখানেই। */
    private fun carrierParagraph(index: Int, pageW: Int, pageH: Int, withSectionBreak: Boolean): String {
        val cx = pageW.toLong() * 635L // twips → EMU
        val cy = pageH.toLong() * 635L
        val sb = StringBuilder(1500)
        sb.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"20\" w:lineRule=\"exact\"/>")
        if (withSectionBreak) {
            sb.append("<w:sectPr><w:pgSz w:w=\"").append(pageW).append("\" w:h=\"").append(pageH).append("\"/>")
            sb.append(PG_MAR).append("</w:sectPr>")
        }
        sb.append("</w:pPr><w:r><w:rPr><w:sz w:val=\"2\"/></w:rPr><w:drawing>")
        sb.append("<wp:anchor distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"")
        sb.append(index).append("\" behindDoc=\"1\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\">")
        sb.append("<wp:simplePos x=\"0\" y=\"0\"/>")
        sb.append("<wp:positionH relativeFrom=\"page\"><wp:posOffset>0</wp:posOffset></wp:positionH>")
        sb.append("<wp:positionV relativeFrom=\"page\"><wp:posOffset>0</wp:posOffset></wp:positionV>")
        sb.append("<wp:extent cx=\"").append(cx).append("\" cy=\"").append(cy).append("\"/>")
        sb.append("<wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/>")
        sb.append("<wp:wrapNone/>")
        sb.append("<wp:docPr id=\"").append(index).append("\" name=\"Page ").append(index).append("\"/>")
        sb.append("<wp:cNvGraphicFramePr/>")
        sb.append("<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">")
        sb.append("<a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">")
        sb.append("<pic:pic xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">")
        sb.append("<pic:nvPicPr><pic:cNvPr id=\"").append(index).append("\" name=\"p").append(index)
        sb.append(".jpg\"/><pic:cNvPicPr/></pic:nvPicPr>")
        sb.append("<pic:blipFill><a:blip r:embed=\"rIdP").append(index).append("\"/>")
        sb.append("<a:stretch><a:fillRect/></a:stretch></pic:blipFill>")
        sb.append("<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"").append(cx)
        sb.append("\" cy=\"").append(cy).append("\"/></a:xfrm>")
        sb.append("<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr>")
        sb.append("</pic:pic></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r></w:p>")
        return sb.toString()
    }

    private fun xmlEscape(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (ch in s) {
            val c = ch.code
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                c == 9 || c == 10 || c == 13 -> sb.append(' ')
                c in 0x20..0xD7FF || c in 0xD800..0xDFFF || c in 0xE000..0xFFFD -> sb.append(ch)
                else -> { /* XML-এ অবৈধ অক্ষর বাদ */ }
            }
        }
        return sb.toString()
    }

    private fun putText(zip: ZipOutputStream, name: String, content: String) {
        zip.setLevel(Deflater.DEFAULT_COMPRESSION)
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    companion object {
        private const val PG_MAR =
            "<w:pgMar w:top=\"0\" w:right=\"0\" w:bottom=\"0\" w:left=\"0\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/>"

        private const val CONTENT_TYPES =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" +
                "<Override PartName=\"/word/document.xml\" " +
                "ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                "</Types>"

        private const val ROOT_RELS =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" " +
                "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" " +
                "Target=\"word/document.xml\"/></Relationships>"

        private const val DOC_HEAD =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<w:document " +
                "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
                "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
                "xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" " +
                "xmlns:w14=\"http://schemas.microsoft.com/office/word/2010/wordml\" " +
                "mc:Ignorable=\"w14\"><w:body>"
    }
}

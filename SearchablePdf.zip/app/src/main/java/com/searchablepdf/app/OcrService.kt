package com.searchablepdf.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors

/**
 * OCR-এর কাজ ফোরগ্রাউন্ড সার্ভিসে চলে, তাই অ্যাপ ব্যাকগ্রাউন্ডে গেলে বা স্ক্রিন বন্ধ হলেও
 * হাজার হাজার পেজের PDF-ও চলতে থাকে।
 */
class OcrService : Service() {

    private val executor = Executors.newSingleThreadExecutor()
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                OcrState.cancelRequested = true
                if (!running) stopSelf()
            }

            ACTION_START -> {
                if (running) return START_NOT_STICKY
                val uri = intent.data
                if (uri == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                val name = intent.getStringExtra(EXTRA_NAME) ?: "document.pdf"
                val skip = intent.getBooleanExtra(EXTRA_SKIP_TEXT, true)
                val toDocx = intent.getStringExtra(EXTRA_MODE) == MODE_DOCX
                val high = intent.getBooleanExtra(EXTRA_HIGH, false)
                val withText = intent.getBooleanExtra(EXTRA_WITH_TEXT, true)
                val editable = intent.getBooleanExtra(EXTRA_EDITABLE, false)

                running = true
                OcrState.cancelRequested = false
                createChannel()
                ServiceCompat.startForeground(
                    this,
                    NOTIF_ID,
                    buildProgressNotification(0, 0, getString(R.string.status_copying)),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
                acquireWakeLock()
                executor.execute { doWork(uri, name, skip, toDocx, high, withText, editable) }
            }

            else -> if (!running) stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        releaseWakeLock()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ কাজ

    private fun doWork(
        uri: Uri,
        displayName: String,
        skipText: Boolean,
        toDocx: Boolean,
        highQuality: Boolean,
        withText: Boolean,
        editable: Boolean
    ) {
        val dir = File(cacheDir, "ocr").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }

        val inFile = File(dir, "input.pdf")
        val baseName = displayName.removeSuffix(".pdf").removeSuffix(".PDF")
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .ifBlank { "document" }
        val outName = if (toDocx) "${baseName}_word.docx" else "${baseName}_searchable.pdf"
        val outMime = if (toDocx) MIME_DOCX else "application/pdf"
        val outFile = File(dir, outName)

        var finalState: OcrUiState
        try {
            OcrState.post(
                OcrUiState(Status.RUNNING, 0, 0, getString(R.string.status_copying))
            )
            copyToFile(uri, inFile)

            val startTime = SystemClock.elapsedRealtime()
            var lastNotif = 0L

            val progress: (Int, Int) -> Unit = { done, total ->
                val msg = progressMessage(done, total, startTime)
                OcrState.post(OcrUiState(Status.RUNNING, done, total, msg))

                val now = SystemClock.elapsedRealtime()
                if (now - lastNotif > 800 || done == total) {
                    lastNotif = now
                    notifyForeground(buildProgressNotification(done, total, msg))
                }
            }

            val result = if (toDocx) {
                DocxExporter(this).run(
                    input = inFile,
                    output = outFile,
                    withText = withText,
                    highQuality = highQuality,
                    editable = editable,
                    isCancelled = { OcrState.cancelRequested },
                    onProgress = progress
                )
            } else {
                PdfOcrEngine(this).run(
                    input = inFile,
                    output = outFile,
                    skipPagesWithText = skipText,
                    isCancelled = { OcrState.cancelRequested },
                    onProgress = progress
                )
            }

            val summary = if (toDocx) {
                getString(
                    R.string.done_summary_docx,
                    result.total, result.ocrPages, result.failedPages, result.words,
                    android.text.format.Formatter.formatFileSize(this, outFile.length())
                )
            } else {
                getString(
                    R.string.done_summary,
                    result.total, result.ocrPages, result.skippedPages,
                    result.failedPages, result.words
                )
            }

            finalState = OcrUiState(
                Status.DONE,
                result.total,
                result.total,
                summary,
                outFile.absolutePath,
                outName,
                outMime
            )
        } catch (e: OcrCancelled) {
            outFile.delete()
            finalState = OcrUiState(Status.CANCELLED, 0, 0, getString(R.string.cancelled))
        } catch (e: InvalidPasswordException) {
            outFile.delete()
            finalState = OcrUiState(Status.ERROR, 0, 0, getString(R.string.error_password))
        } catch (e: SecurityException) {
            outFile.delete()
            finalState = OcrUiState(Status.ERROR, 0, 0, getString(R.string.error_password))
        } catch (e: OutOfMemoryError) {
            outFile.delete()
            finalState = OcrUiState(Status.ERROR, 0, 0, getString(R.string.error_memory))
        } catch (e: IOException) {
            outFile.delete()
            val msg = if (e.message?.contains("ENOSPC", true) == true ||
                e.message?.contains("space", true) == true
            ) getString(R.string.error_space) else getString(R.string.error_open)
            finalState = OcrUiState(Status.ERROR, 0, 0, msg)
        } catch (e: Throwable) {
            outFile.delete()
            finalState = OcrUiState(
                Status.ERROR, 0, 0,
                getString(R.string.error_prefix, e.message ?: e.javaClass.simpleName)
            )
        } finally {
            inFile.delete()
        }

        OcrState.post(finalState)
        postFinishedNotification(finalState)

        running = false
        releaseWakeLock()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun copyToFile(uri: Uri, dest: File) {
        val input = contentResolver.openInputStream(uri)
            ?: throw IOException("ফাইল পড়া যায়নি")
        input.use { ins ->
            dest.outputStream().use { outs ->
                val buf = ByteArray(256 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    outs.write(buf, 0, n)
                }
            }
        }
    }

    private fun progressMessage(done: Int, total: Int, startTime: Long): String {
        if (done <= 0 || total <= 0 || done >= total) {
            return getString(R.string.status_progress, done, total)
        }
        val elapsed = SystemClock.elapsedRealtime() - startTime
        val remainingMs = elapsed / done * (total - done)
        val minutes = (remainingMs / 60000L).toInt()
        val eta = when {
            minutes < 1 -> getString(R.string.eta_less_than_minute)
            minutes < 60 -> getString(R.string.eta_minutes, minutes)
            else -> getString(R.string.eta_hours_minutes, minutes / 60, minutes % 60)
        }
        return getString(R.string.status_progress_eta, done, total, eta)
    }

    // ------------------------------------------------------------- নোটিফিকেশন

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        getString(R.string.notif_channel),
                        NotificationManager.IMPORTANCE_LOW
                    )
                )
            }
        }
    }

    private fun openAppIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildProgressNotification(done: Int, total: Int, text: String): Notification {
        val cancelIntent = PendingIntent.getService(
            this, 1,
            Intent(this, OcrService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
            .addAction(0, getString(R.string.cancel), cancelIntent)
        if (total > 0) b.setProgress(total, done, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    @SuppressLint("MissingPermission")
    private fun notifyForeground(n: Notification) {
        try {
            NotificationManagerCompat.from(this).notify(NOTIF_ID, n)
        } catch (_: Exception) {
        }
    }

    @SuppressLint("MissingPermission")
    private fun postFinishedNotification(state: OcrUiState) {
        if (state.status == Status.CANCELLED) return
        val text = if (state.status == Status.DONE) getString(R.string.notif_done)
        else getString(R.string.notif_failed)
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        try {
            NotificationManagerCompat.from(this).notify(NOTIF_ID_DONE, n)
        } catch (_: Exception) {
        }
    }

    // --------------------------------------------------------------- WakeLock

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "searchablepdf:ocr").apply {
                setReferenceCounted(false)
                acquire(6L * 60 * 60 * 1000)
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    companion object {
        const val ACTION_START = "com.searchablepdf.app.START"
        const val ACTION_CANCEL = "com.searchablepdf.app.CANCEL"
        const val EXTRA_NAME = "name"
        const val EXTRA_SKIP_TEXT = "skip_text"
        const val EXTRA_MODE = "mode"
        const val EXTRA_HIGH = "high_quality"
        const val EXTRA_WITH_TEXT = "with_text"
        const val EXTRA_EDITABLE = "editable"
        const val MODE_PDF = "pdf"
        const val MODE_DOCX = "docx"
        const val MIME_DOCX =
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

        private const val CHANNEL_ID = "ocr_progress"
        private const val NOTIF_ID = 101
        private const val NOTIF_ID_DONE = 102
    }
}

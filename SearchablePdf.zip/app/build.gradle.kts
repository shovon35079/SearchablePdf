plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.searchablepdf.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.searchablepdf.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // শুধু মোবাইলের জন্য — APK ছোট রাখতে x86 বাদ
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/AL2.0",
                "/META-INF/LGPL2.1",
                "/META-INF/DEPENDENCIES",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*"
            )
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.8.7")

    // অফলাইন OCR (ইংরেজি/ল্যাটিন) — মডেল অ্যাপের ভেতরেই থাকে, ইন্টারনেট লাগে না
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")

    // মূল PDF-এর পেজ না বদলিয়ে তার ওপর অদৃশ্য টেক্সট লেয়ার বসানোর জন্য
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
